import teal from "./list/teal";
import red from "./list/red";
import gray from "./list/gray";
import blck from "./list/blck";

export const allThemes = [
  teal,
  gray,
  red,
  blck
]
